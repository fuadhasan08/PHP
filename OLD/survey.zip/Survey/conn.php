<?php
    require_once("conf.php");
    $arr = [];
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "survey";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
?>